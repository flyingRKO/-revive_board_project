package com.example.communityforum.domain.constant;

public enum BoardType {
    NOTICE, FORUM
}
