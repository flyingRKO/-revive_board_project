package com.example.communityforum.domain.constant;

public enum Role {
    ADMIN, GENERAL
}
